import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import TableThree from '../components/Tables/TableThree';
import DefaultLayout from '../layout/DefaultLayout';
import axios from 'axios';
import baseUrl from '../utils/axios';
import { useEffect, useState } from 'react';
import OrdersDetails from '../components/OrdersDetails';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const Orders = () => {
  const [AllOrders, setAllOrders] = useState([]);
  const [OrderIndex, setOrderIndex] = useState([]);
  const [active, setactive] = useState(false);
  const [Status, setStatus] = useState([]);

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [orderIdFilter, setOrderIdFilter] = useState();
  const [shippingIdFilter, setShippingIdFilter] = useState('');
  const [customerIdFilter, setCustomerIdFilter] = useState('');

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // const [prevPage, setprevPage] = useState(0)
  const [Page, setPage] = useState(0)
  const [pageSize, setpageSize] = useState(5)
  


  const getAllOrders = () => {
    axios.defaults.headers.common['ngrok-skip-browser-warning'] = 'any value';
    axios.get(baseUrl + `order/?pageNumber=${Page}&pageSize=${pageSize}`).then((res) => {
      // console.log(res)
      setAllOrders(res.data.orders.orders);
      console.log(res.data.orders.orders);
    });
  };

  const PrevPage = ()=>{

    if(Page >= 1){
      setPage(Page-1)
    }else{
      alert("You are on the First Page")
    }
    console.log("prevPage", Page)
  } 
   const NextPage = ()=>{

    setPage(Page+1)
    console.log("nextPage", Page)
  }

  const itemsPerPage = (event)=>{
    setpageSize(parseInt(event.target.value))
    setPage(0)
    console.log("itemsPerPage", event.target.value)
  }


  // const getAllOrders = () => {
  //   axios.defaults.headers.common['ngrok-skip-browser-warning'] = 'any value';
  //   axios.get(baseUrl + 'order/').then((res) => {
  //     // console.log(res)
  //     setAllOrders(res.data.orders.orders);
  //     console.log(res.data.orders.orders);
  //   });
  // };

  // ------------------ Filter ----------------

  const filteredOrders = AllOrders.filter((packageItem) => {
    const orderDate = new Date(packageItem.order_date);
    const start = startDate ? new Date(startDate) : null;
    const end = endDate ? new Date(endDate) : null;
    const isDateInRange =
      (!start || orderDate >= start) && (!end || orderDate <= end);
    const isOrderIdMatch = orderIdFilter
      ? packageItem.order_id === Number(orderIdFilter)
      : true;
    const isShippingIdMatch = shippingIdFilter
      ? packageItem.shipping_id === Number(shippingIdFilter)
      : true;
    const isCustomerIdMatch = customerIdFilter
      ? packageItem.customer_id === Number(customerIdFilter)
      : true;

      // const isStatusMatch = statusFilter
      // ? packageItem.order_status === (statusFilter)
      // : true;
      
    return (
      isDateInRange && isOrderIdMatch && isShippingIdMatch && isCustomerIdMatch
    );
  });

  const getStatus = () => {
    axios.get(baseUrl + 'orderStatus/').then((res) => {
      // console.log(res)
      console.log(res.data.object.body);
      setStatus(res.data.object.body);
    });
  };

  const OrderDetails = (id, index) => {
    // console.log(vendorData[index])
    // setSingleVendorData([vendorData[index]])
    // setDisplay("flex")
    // setBgColor("blur-sm")
    // setevents("pointer-events-none")
    AllOrders.find((orders)=>{
      if(id == orders.order_id){
        // console.log(orders)
        setOrderIndex(orders);
      }
    });
    // console.log(id)
    setactive(true);
  };

  const UpdateStatus = (e, i, id) => {
    const isConfirmed = window.confirm(
      'Are you sure you want to update the status?',
    );

    if (isConfirmed) {


      // AllOrders.find((orders)=>{
      //   if(id == orders.order_id){
      //     // console.log(orders)
      //     setOrderIndex(orders);
      //   }

      AllOrders.find((orders)=>{
        if(id == orders.order_id){
          orders.order_status = e;
          setAllOrders([...AllOrders]);
        }
      })


      // AllOrders[i].order_status = e;
      // setAllOrders([...AllOrders]);

      let statusId = Status.find((s) => {
        return s.status === e;
      });

      axios
        .put(baseUrl + 'order/update', {
          orderId: id,
          orderStatusId: statusId.orderStatusId,
        })
        .then((response) => {
          console.log(response.status);
        });
    } else {
      console.log('Status update cancelled');
    }
  };

  useEffect(() => {
    getAllOrders();
    getStatus();
  }, [Page,pageSize]);

  //   ------------------ Optains variable for Time Formate --------------
  const options = {
    weekday: 'short', // Full name of the day of the week
    year: 'numeric',
    month: 'numeric', // Abbreviated name of the month
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: true, // Use 12-hour format
  };

  console.log(pageSize)


  return (
    <DefaultLayout>
      <Breadcrumb
        pageName={`${active === true ? 'Order Details' : 'Orders'}`}
      />

      {/* <div className='flex bg-white fixed bottom-0 right-0 gap-4 text-3xl p-4'>
          <button>&#8249;</button>
          <button>&#8250;</button>
      </div> */}
      {/* --------------------- Order Details Component ---------------------- */}

      {active === true ? (
        <div className="flex flex-col bg-[#e5e7e px-8 relative">
          <OrdersDetails
            AllOrders={AllOrders}
            OrderIndex={OrderIndex}
            setactive={setactive}
          />
        </div>
      ) : (
        <div>
          <div className="absolute right-18 top-50 z-99 ">
            <button
              className="p-2 bg-blue-500 text-white rounded min-w-[200px] flex justify-center items-center gap-2"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="currentColor"
                height="20"
                width="20"
              >
                <path d="M10 18H14V16H10V18ZM3 6V8H21V6H3ZM6 13H18V11H6V13Z"></path>
              </svg>
              Filter By
            </button>

            {isDropdownOpen && (
              <div className="absolute mt-2 bg-white p-2 rounded shadow z-99">
                <input
                  type="number"
                  className="p-1 border-2 border-black rounded  mb-2 "
                  placeholder="Order ID"
                  value={orderIdFilter}
                  onChange={(e) => setOrderIdFilter(e.target.value)}
                />

                <input
                  type="number"
                  className="p-1 border-2 border-black rounded  mb-2 "
                  placeholder="Shipping ID"
                  value={shippingIdFilter}
                  onChange={(e) => setShippingIdFilter(e.target.value)}
                />

                <input
                  type="number"
                  className="p-1 border-2 border-black rounded "
                  placeholder="Customer ID"
                  value={customerIdFilter}
                  onChange={(e) => setCustomerIdFilter(e.target.value)}
                />
              </div>
            )}
          </div>

          <div className="flex flex-col gap-10 ">
            <div className="rounded-sm border border-stroke bg-white px-5 pt-6 pb-2.5 shadow-default dark:border-strokedark dark:bg-boxdark sm:px-7.5 xl:pb-1">
              <div className="max-w-full overflow-x-auto">
                <div className="relative p-2 flex gap-10 ">
                  <div className="mb-2 flex gap-1">
                    <DatePicker
                      className="text-black p-1 border-2 border-black rounded focus:outline-none focus:border-blue-500 hover:border-blue-300 transition duration-200 ease-in-out"
                      placeholderText="Start Date"
                      dateFormat="dd/MM/yyyy"
                      selected={startDate ? new Date(startDate) : null}
                      onChange={(date) =>
                        setStartDate(date.toISOString().split('T')[0])
                      }
                    />
                    <span className="text-2xl">-</span>
                    <DatePicker
                      className="text-black p-1 border-2 border-black rounded focus:outline-none focus:border-blue-500 hover:border-blue-300 transition duration-200 ease-in-out"
                      placeholderText="End Date"
                      dateFormat="dd/MM/yyyy"
                      selected={endDate ? new Date(endDate) : null}
                      onChange={(date) =>
                        setEndDate(date.toISOString().split('T')[0])
                      }
                    />
                  </div>

                  {startDate > endDate
                    ? 'end date should be greater'
                    : filteredOrders.length + ' results Found'}

                  {/* 
                  <div>
                  <select
                            className={`inline-flex rounded-full bg-opacity-10 py-1 px-3 text-sm font-medium outline-1 outline-slate-400 ${
                              filteredOrders.order_status === 'successfull'
                                ? 'bg-success text-success'
                                : filteredOrders.order_status === 'confirm'
                                ? 'bg-blue-400 text-blue-700'
                                : 'bg-warning text-warning'
                            }`}
                            value={filteredOrders.order_status}
                            onChange={(e)=>console.log(e.target.value)}
                          >
                            {Status.map((status) => (
                              <option
                                key={status.orderStatusId}
                                value={status.status}
                              >
                                {status.status}
                              </option>
                            ))}
                          </select>
                  </div> */}
                </div>

                <table className="w-full table-auto">
                  <thead>
                    <tr className="bg-gray-2 text-left dark:bg-meta-4">
                      <th className="min-w-[100px] py-4 px-4 font-medium text-black dark:text-white xl:pl-11">
                        Order ID
                      </th>
                      <th className="min-w-[150px] py-4 px-4 font-medium text-black dark:text-white">
                        Invoice date
                      </th>
                      <th className="min-w-[120px] py-4 px-4 font-medium text-black dark:text-white">
                        shipping ID
                      </th>
                      <th className="min-w-[120px] py-4 px-4 font-medium text-black dark:text-white">
                        Status
                      </th>
                      <th className="py-4 px-4 font-medium text-black dark:text-white">
                        See Details
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* {AllOrders.map((packageItem, key) => (
                    <tr key={key}>
                      <td className="border-b border-[#eee] py-5 px-4 pl-9 dark:border-strokedark xl:pl-11">
                        <h5 className="font-medium text-black dark:text-white">
                          {packageItem.order_id}
                        </h5>
                      </td>
                      <td className="border-b border-[#eee] py-5 px-4 dark:border-strokedark">
                        <p className="text-black dark:text-white">
                          {new Intl.DateTimeFormat('en-IN', options).format(
                            new Date(packageItem.order_date),
                          )}
                        </p>
                      </td>
                      <td className="border-b border-[#eee]  pl-9 dark:border-strokedark xl:pl-11">
                        <h5 className="font-medium text-black dark:text-white">
                          {packageItem.shipping_id}
                        </h5>
                      </td>
                      <td className="border-b border-[#eee] dark:border-strokedark">
                        <select
                          className={`inline-flex rounded-full bg-opacity-10 py-1 px-3 text-sm font-medium outline-1 outline-slate-400 ${
                            packageItem.order_status === 'successfull'
                              ? 'bg-success text-success'
                              : packageItem.order_status === 'confirm'
                              ? 'bg-blue-400 text-blue-700'
                              : 'bg-warning text-warning'
                          }`}
                          value={packageItem.order_status}
                          onChange={(event) =>
                            UpdateStatus(
                              event.target.value,
                              key,
                              packageItem.order_id,
                            )
                          }
                        >
                          {Status.map((status) => (
                            <option
                              key={status.orderStatusId}
                              value={status.status}
                            >
                              {status.status}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="border-b border-[#eee] dark:border-strokedark ">
                        <div className="bg-red-5 flex justify-center space-x-3.5">
                          <button
                            onClick={() => OrderDetails(key)}
                            className="hover:text-primary"
                          >
                            view
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))} */}

                    {filteredOrders.map((packageItem, key) => (
                      <tr key={key}>
                        <td className="border-b border-[#eee] py-5 px-4 pl-9 dark:border-strokedark xl:pl-11">
                          <h5 className="font-medium text-black dark:text-white">
                            {packageItem.order_id}
                          </h5>
                        </td>
                        <td className="border-b border-[#eee] py-5 px-4 dark:border-strokedark">
                          <p className="text-black dark:text-white">
                            {new Intl.DateTimeFormat('en-IN', options).format(
                              new Date(packageItem.order_date),
                            )}
                          </p>
                        </td>
                        <td className="border-b border-[#eee]  pl-9 dark:border-strokedark xl:pl-11">
                          <h5 className="font-medium text-black dark:text-white">
                            {packageItem.shipping_id}
                          </h5>
                        </td>
                        <td className="border-b border-[#eee] dark:border-strokedark">
                          <select
                            className={`inline-flex rounded-full bg-opacity-10 py-1 px-3 text-sm font-medium outline-1 outline-slate-400 ${
                              packageItem.order_status === 'successfull'
                                ? 'bg-success text-success'
                                : packageItem.order_status === 'confirm'
                                ? 'bg-blue-400 text-blue-700'
                                : 'bg-warning text-warning'
                            }`}
                            value={packageItem.order_status}
                            onChange={(event) =>
                              UpdateStatus(
                                event.target.value,
                                key,
                                packageItem.order_id,
                              )
                            }
                          >
                            {Status.map((status) => (
                              <option
                                key={status.orderStatusId}
                                value={status.status}
                              >
                                {status.status}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="border-b border-[#eee] dark:border-strokedark ">
                          <div className="bg-red-5 flex justify-center space-x-3.5">
                            <button
                              onClick={() =>
                                OrderDetails(packageItem.order_id, key)
                              }
                              className="hover:text-primary"
                            >
                              view
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* ------------------- Pagination ------------------- */}
                <div className="flex items-center justify-end bg-whiten bottom-0 right-0 gap-2 text-3xl px-12 p-2">
                  <div className='flex'>
                    <span className='text-base flex justify-center items-center bg-slate-40 p-0 px-5'>Items Per Page : </span>
                    <select onChange={(event)=>itemsPerPage(event)} name="" id=""  className='text-base flex justify-center items-center bg-slate-40 p-0 px-2 bg-transparent border-b outline-neutral-500 mr-5'>
                      <option selected value="5">5</option>
                      <option value="10">10</option>
                      <option value="20">20</option>
                    </select>
                  </div>
                  <button className=' text-center p-0 px-5 bg-red-00' onClick={PrevPage}>&#8249;</button>
                  <span className='text-base flex justify-center items-center bg-slate-40 p-0 px-5'>{Page + 1} / 6</span>
                  <button  className=' text-center p-0 px-5 bg-red-00' onClick={NextPage}>&#8250;</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </DefaultLayout>
  );
};

export default Orders;
