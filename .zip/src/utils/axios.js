// import axios from "axios";

// const api = axios.create({
//     baseURL: "https://350f-2405-201-3037-e833-9cd1-a882-416e-6d8e.ngrok-free.app/"
// })

const baseURL= "https://1lzm87guor2f.share.zrok.io/"
// const baseURL= "https://6680-2405-201-a426-a02e-3195-b183-254d-b588.ngrok-free.app/"



export default baseURL;