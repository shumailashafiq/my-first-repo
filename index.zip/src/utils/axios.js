// import axios from "axios";

// const api = axios.create({
//     baseURL: "https://350f-2405-201-3037-e833-9cd1-a882-416e-6d8e.ngrok-free.app/"
// })

const baseURL= "https://hvs66vfvbevy.share.zrok.io/"
// const baseURL= "https://0c2c-2405-201-3037-e833-4498-c853-f591-cf6c.ngrok-free.app/"



export default baseURL;