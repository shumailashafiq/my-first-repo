
const baseURL= "https://90ed-2405-201-3037-e833-68de-8379-ca9-756c.ngrok-free.app/"

export default baseURL;