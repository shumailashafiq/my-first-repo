import baseUrl from '../../utils/axios';
import DefaultLayout from '../../layout/DefaultLayout';
import { Outlet, useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import Breadcrumb from '../Breadcrumbs/Breadcrumb';
import axios from 'axios';

const ProductItemImage = () => {
  const [image, setimage] = useState('');
  const navigate = useNavigate();

  const FormDataa = new FormData();
  FormDataa.append('image', image);

  axios
    .post(baseUrl + '/saveimage', FormDataa, {
      headers: {
        'Content-Type': 'multipart/form-data', // Set the content type to multipart/form-data
      },
    })
    .then((res) => {
      console.log(res.data);
      window.location.reload();
    });
  navigate('../');

  return (
    <>
      <div>
        {/* <DefaultLayout />
        <Breadcrumb /> */}
      </div>

      {/* ------------ Outlet for Creating new Vendor -------------- */}

      <Outlet />

      <div>
        <label className="mb-2.5 block text-black dark:text-white">
          Product Item Image
        </label>
        <input
          type="file"
          onChange={(event) => setimage(event.target.files[0])} // Use event.target.files to get the file object

          className="w-full border-[1.5px] border-stroke bg-transparent py-3 px-5 text-black outline-none transition focus:border-primary active:border-primary disabled:cursor-default disabled:bg-whiter dark:border-form-strokedark dark:bg-form-input dark:text-white dark:focus:border-primary"
        />
        <button
          type="submit"
          className="flex w-full justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90"
        >
          Submit
        </button>
        <Outlet />
      </div>

    </>
  );
};
export default ProductItemImage;
