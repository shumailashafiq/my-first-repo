import React from 'react'

const OrderDetails = () => {
  return (
    <div>OrderDetails</div>
  )
}

export default OrderDetails